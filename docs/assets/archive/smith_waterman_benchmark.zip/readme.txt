Instructions
------------

1) Build UGENE with CoreTests and TestLauncher plugins.
These plugins are not included into the source bundle, however you can find them in the svn:
https://ugene.unipro.ru/svn/ugene/trunk

When building ugene, don't forget to set UGENE_CUDA_DETECTED=1

2) After UGENE is built succesfully, make sure your GPU is detected.
Launch trunk/src/_release/ugeneui and check GPU settings.

3) Launch tests from command line using the following command:
./ugenecl --test-threads=1 --log-level="DETAILS" --test-suite=/path/to/testsuite/smith_waterman_perf.xml

Contacts
--------

Unipro UGENE team e-mail:
ugene@unipro.ru